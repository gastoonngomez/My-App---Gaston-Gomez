import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import  Navbarmenu from './components/navbar.js';


function App(){

    return(
<div>
        <h1>Hola, esto es Home</h1>
        </div>)
}