import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import  Navbarmenu from './components/navbar.js';




 
//const style = {
  //backgroundColor:'red',
  //color: 'blue',
  //fontSize:'301',
  //textAlign:'center'

//}


function App() {

  return(  
<Navbarmenu />
  
  );
}

function World(){
  return <div style={{ }}>
  Hello World!
  
</div>
  
}



export default App;